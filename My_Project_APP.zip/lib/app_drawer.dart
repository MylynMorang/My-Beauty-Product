import 'package:flutter/material.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final List<String> news = [
      'Top Stories',
      'World',
      'Business',
      'Technology',
      'Entertainment',
      'Sports',
      'Science',
      'Health',
    ];

    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          // ✅ Drawer Header
          DrawerHeader(
            decoration: const BoxDecoration(
              color: Color(0xffed78a4),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: const [
                Icon(Icons.store, color: Color(0xff000000), size: 40),
                SizedBox(height: 10),
                Text(
                  'My Beauty Product',
                  style: TextStyle(
                    color: Color(0xffffe1e1),
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),

          // ✅ Navigation items
          _buildDrawerItem(
            context,
            icon: Icons.shopping_bag,
            title: 'Shop',
            routeName: '/shop',
          ),
          _buildDrawerItem(
            context,
            icon: Icons.newspaper,
            title: 'Newsstand',
            routeName: '/newsstand',
            arguments: {'news': news},
          ),
          _buildDrawerItem(
            context,
            icon: Icons.info,
            title: 'Who We Are',
            routeName: '/info',
          ),
          _buildDrawerItem(
            context,
            icon: Icons.person,
            title: 'My Profile',
            routeName: '/myprofile',
          ),
          // Commented out until route is ready
          // _buildDrawerItem(
          //   context,
          //   icon: Icons.favorite,
          //   title: 'My Favorite',
          //   routeName: '/myfavorite',
          // ),
          _buildDrawerItem(
            context,
            icon: Icons.shopping_cart,
            title: 'Basket',
            routeName: '/cart',
          ),
        ],
      ),
    );
  }

  // ✅ Reusable ListTile builder
  Widget _buildDrawerItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String routeName,
    Map<String, dynamic>? arguments,
  }) {
    return ListTile(
      leading: Icon(icon, color: Color(0xfff081a6)),
      title: Text(title),
      onTap: () {
        Navigator.pop(context); // close the drawer first
        Navigator.pushNamed(context, routeName, arguments: arguments);
      },
    );
  }
}
