import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

// 📦 Local imports
import 'package:my_grocery_app/app_drawer.dart';
import 'package:my_grocery_app/cart.dart';
import 'package:my_grocery_app/info.dart';
import 'package:my_grocery_app/newsstand.dart';
import 'package:my_grocery_app/profile.dart';
import 'package:my_grocery_app/shop.dart';
import 'package:my_grocery_app/provider.dart'; // 🛒 CartProvider
import 'package:my_grocery_app/favorite_provider.dart'; // ❤️ FavoriteProvider

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => CartProvider()),
        ChangeNotifierProvider(create: (context) => FavoriteProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Beauty Product',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true, // ✅ Uses Material 3 modern UI
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff003ab7)),
      ),
      home: const MyHomePage(title: 'My Beauty Product'),
      routes: {
        '/shop': (context) => const Shop(),
        '/newsstand': (context) => const Newsstand(),
        '/info': (context) => const Info(),
        '/myprofile': (context) => const MyProfile(),
        '/cart': (context) => const Cart(),
        // You can add a favorites page later if needed.
      },
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        centerTitle: true,
        backgroundColor: Color(0xfff2b6b6),
        elevation: 2,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      drawer: const AppDrawer(),
      body: const Center(
        child: Text(
          'Welcome to My Beauty Product',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Colors.black87,
          ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
